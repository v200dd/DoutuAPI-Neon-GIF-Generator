# main.py
from fastapi import FastAPI, Query, HTTPException
from fastapi.responses import Response
from gif_generator import generate_gif_bytes

app = FastAPI(
    title="Text to GIF API",
    description="Generate transparent GIFs from text.",
    version="1.4.0"
)

@app.get("/generate")
async def get_gif(
    text: str = Query(..., min_length=1, description="Text content"),
    frame: int = Query(5, ge=1, description="Speed/Frames"),
    delay: int = Query(100, ge=20, description="Delay (ms)"),
    color: str = Query(None, description="Color (e.g. red, rainbow)"),
    
    # --- 修改这里 ---
    # 1. 默认值改为 500
    # 2. 描述改为 "Image width in pixels"
    # 3. 去掉 le=20 这种限制，给个合理的范围比如 50 - 2000
    width: int = Query(500, ge=50, le=2000, description="Image width in pixels (e.g., 500)"),
    
    theme: str = Query("transparent", enum=["transparent", "dark", "light"], description="Theme")
):
    """
    Generate a GIF image.
    Width is now in PIXELS (default 500px).
    Height is fixed at 100px.
    """
    try:
        gif_buffer = generate_gif_bytes(
            text=text,
            frame=frame,
            delay=delay,
            font_path=None,
            text_color=color,
            width=width,  # 这里传入的就是 500 了
            theme=theme
        )

        if not gif_buffer:
            raise HTTPException(status_code=400, detail="Failed to generate GIF.")

        return Response(content=gif_buffer.getvalue(), media_type="image/gif")
    
    except Exception as e:
        print(e)
        raise HTTPException(status_code=500, detail="Server Error")

if __name__ == "__main__":
    import uvicorn
    uvicorn.run("main:app", host="0.0.0.0", port=8008, reload=True)