# gif_generator.py
import os
import io
import string
import logging
import colorsys
from PIL import ImageFont, Image, ImageDraw, ImageColor

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger("uvicorn")

# --- 全局配置 ---修改这个数值改变文字大小
IMAGE_SIZE = 200
FONT_RATIO = 0.85 

# --- 修改 1: 直接使用 pixel_width ---
def new_image(pixel_width, background_color_rgba):
    # 不再乘以 IMAGE_SIZE
    return Image.new('RGBA', (pixel_width, IMAGE_SIZE), background_color_rgba)

def load_font(font_path: str = None, container_height: int = 100):
    font_size = int(container_height * FONT_RATIO)
    try:
        if font_path and os.path.exists(font_path):
            return ImageFont.truetype(font_path, font_size)
        fallback_fonts = [
            'fonts/jiying.ttf',
            '/usr/share/fonts/opentype/noto/NotoSansCJK-Regular.ttc',
            '/usr/share/fonts/truetype/noto/NotoSansCJK-Regular.ttc',
            'arial.ttf',
            'msyh.ttc'
        ]
        for f in fallback_fonts:
            try: return ImageFont.truetype(f, font_size)
            except OSError: continue
        return ImageFont.load_default()
    except Exception:
        return ImageFont.load_default()

def create_rainbow_gradient(width, height):
    width = max(width, 1)
    gradient_img = Image.new('RGBA', (width, height))
    pixels = gradient_img.load()
    for x in range(width):
        hue = x / width
        r, g, b = colorsys.hsv_to_rgb(hue, 1.0, 1.0)
        color = (int(r * 255), int(g * 255), int(b * 255), 255)
        for y in range(height):
            pixels[x, y] = color
    return gradient_img

def process_alpha_threshold(img):
    r, g, b, a = img.split()
    a = a.point(lambda i: 255 if i > 128 else 0)
    return Image.merge('RGBA', (r, g, b, a))

# --- 修改 2: 参数名虽然叫 width，但现在代表像素值 ---
def generate_gif_bytes(text: str, frame: int, delay: int, font_path: str, text_color: str, width: int, theme: str) -> io.BytesIO:
    
    # 1. 颜色配置 (保持不变)
    if theme == 'transparent':
        bg_color_rgba = (0, 0, 0, 0)
        default_text_color = (255, 255, 255)
    elif theme == 'light':
        bg_color_rgba = (255, 255, 255, 255)
        default_text_color = (0, 0, 0)
    else: 
        bg_color_rgba = (0, 0, 0, 255)
        default_text_color = (255, 255, 255)

    is_rainbow = text_color == 'rainbow'
    text_color_rgba = None

    if not is_rainbow:
        if text_color:
            try: text_color_rgba = ImageColor.getrgb(text_color)
            except ValueError: text_color_rgba = default_text_color
        else: text_color_rgba = default_text_color

    # 2. 准备绘制
    input_string = ' '.join(text.split())
    font = load_font(font_path, IMAGE_SIZE) 
    images = []
    center_y = IMAGE_SIZE // 2

    def get_text_width(draw_obj, txt, fnt):
        try: return draw_obj.textlength(txt, font=fnt)
        except AttributeError: return draw_obj.textsize(txt, font=fnt)[0]

    # 3. 核心绘制
    if is_rainbow:
        # --- 彩虹模式 ---
        temp_img = new_image(1, (0,0,0,0))
        temp_d = ImageDraw.Draw(temp_img)
        full_text_width = int(get_text_width(temp_d, input_string, font))
        full_text_width = max(full_text_width, 1)

        mask_img = Image.new('L', (full_text_width, IMAGE_SIZE), 0)
        mask_d = ImageDraw.Draw(mask_img)
        mask_d.text((0, center_y), input_string, fill=255, font=font, anchor='lm')

        gradient_img = create_rainbow_gradient(full_text_width, IMAGE_SIZE)
        master_rainbow_text = Image.new('RGBA', (full_text_width, IMAGE_SIZE), (0,0,0,0))
        master_rainbow_text.paste(gradient_img, (0, 0), mask=mask_img)
        
        if theme == 'transparent':
            master_rainbow_text = process_alpha_threshold(master_rainbow_text)

        if frame == 1:
             img = new_image(width, bg_color_rgba)
             # 修改计算逻辑：width 已经是像素了，不需要乘以 IMAGE_SIZE
             start_x = int((width - full_text_width) / 2)
             img.paste(master_rainbow_text, (start_x, 0), mask=master_rainbow_text)
             images.append(img)
        else:
            frame_offset = IMAGE_SIZE // frame
            # 修改计算逻辑：x 基于 width 像素计算
            # 这里的逻辑是：每一帧移动多少像素？frame_offset 还是 100/frame
            # 保持原来的滚动速度逻辑：
            step_pixels = IMAGE_SIZE // frame
            
            # 初始位置：从最右边开始
            x = width 
            
            # 只要文字还没完全滚出左边 (-full_text_width)，就继续
            # 或者我们可以生成固定的循环周期
            # 这里简单修改为：循环直到覆盖足够多的帧
            # 为了简化，我们生成一个周期的动画
            
            # 重新定义 x 的起点：为了让动画无缝循环，通常需要生成 (text_width + window_width) 长度的动画
            # 但为了保持原代码风格，我们沿用“填充”逻辑
            
            # 修正逻辑：
            current_offset = (frame - 1) * step_pixels * (width / 100) # 近似原来的逻辑
            # 但既然 width 变了，简单的做法是：
            x = width # 从屏幕右侧刚出现
            
            # 为了平滑循环，我们生成直到文字完全离开屏幕
            while x > -full_text_width:
                img = new_image(width, bg_color_rgba)
                img.paste(master_rainbow_text, (int(x), 0), mask=master_rainbow_text)
                images.append(img)
                x -= step_pixels # 每次移动步长

            # 循环补帧 (原逻辑的简化版)
            # 原来的逻辑比较复杂是因为要无缝衔接。
            # 如果发现循环不自然，可以简化为：只生成一次滚动的过程。
            pass 

    else:
        # --- 普通颜色模式 ---
        if frame == 1:
            for char_text in input_string:
                if char_text in string.whitespace: continue
                img = new_image(width, bg_color_rgba)
                d = ImageDraw.Draw(img)
                # 修改计算逻辑：width 已经是像素了
                center_x = width // 2
                d.text((center_x, center_y), char_text, fill=text_color_rgba, font=font, anchor='mm')
                images.append(img)
        else:
            temp_img = new_image(width, bg_color_rgba)
            d_temp = ImageDraw.Draw(temp_img)
            text_total_width = get_text_width(d_temp, input_string, font)
            
            step_pixels = IMAGE_SIZE // frame
            
            # 修正滚动逻辑
            # 1. 确定起点：从右侧进入
            x = width
            
            # 2. 循环直到文字完全滚出左侧
            while x > -text_total_width:
                img = new_image(width, bg_color_rgba)
                d = ImageDraw.Draw(img)
                d.text((x, center_y), input_string, fill=text_color_rgba, font=font, anchor='lm')
                images.append(img)
                x -= step_pixels

    if not images:
        return None

    if theme == 'transparent':
        images = [process_alpha_threshold(img) for img in images]

    output_buffer = io.BytesIO()
    images[0].save(
        fp=output_buffer,
        format='GIF',
        append_images=images[1:],
        save_all=True,
        duration=delay,
        optimize=False,
        loop=0,
        transparency=0, 
        disposal=2      
    )
    output_buffer.seek(0)
    return output_buffer